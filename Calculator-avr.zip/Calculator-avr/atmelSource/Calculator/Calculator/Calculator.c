/*
8-BIT Calculator 
Controller AtMega 16

*/

#include <avr/io.h>
#include <util/delay.h>
#include <string.h>
#include <stdbool.h>

//Define Controller Speed
#ifndef F_CPU
#define F_CPU 4000000UL // 16 MHz clock speed
#endif

//LCD Pin Configuration
#define D4 eS_PORTC0
#define D5 eS_PORTC1
#define D6 eS_PORTC2
#define D7 eS_PORTC3
#define RS eS_PORTC4
#define EN eS_PORTC5

//KeyPad Pin Configuration
#define W1 eS_PORTD0
#define W2 eS_PORTD1
#define W3 eS_PORTD2
#define W4 eS_PORTD3
#define R1 eS_PORTD4
#define R2 eS_PORTD5
#define R3 eS_PORTD6
#define R4 eS_PORTD7

#include "lcd.h"
#define delay 300
uint32_t sum = 0;
uint32_t num = 0;
char sign = '0';

void handle_number(int a)
{

	if (num <= 1000000000)
	{
		num *= 10;
		num += a;
	}

		Lcd4_Set_Cursor(2, 1);
		char snum[10];
		ltoa(num, snum, 10);
		Lcd4_Write_String(snum);

}

void handle_sign(char a)
{
	Lcd4_Clear();
	Lcd4_Set_Cursor(2, 1);

	if (sign == '0')
		sum = num;
	else
	{
		if (sign == '+')
		{
			sum = sum + num;
			
		}
		else if (sign == '-')
		{
			sum = sum - num;
		
		}
		else if (sign == '*')
		{
			sum = sum * num;
			
		}
		else if (sign == '/')
		{
			sum = sum / num;
	
	    }
	}	
	sign = a;
	num = 0;
	Lcd4_Write_Char(sign);
}

int main(void)
{
	DDRD = 0x0F; //keypad pins first 4-Pins out and last 8-Pins Input
	DDRC = 0xFF; //LCD pins
	int i;
	Lcd4_Init();
	Lcd4_Set_Cursor(1, 1);
	Lcd4_Write_String("AT Mega16 Calc");
	Lcd4_Set_Cursor(2, 5);
	Lcd4_Write_String("Project");
	_delay_ms(2500);
	Lcd4_Clear();
	while (1)
	{
		KeyPad_Read();
		LCD_Write();	
	}
}

//Read Keypad Pins Status
void KeyPad_Read()
{

	/********************************Check First Row****************************/
	PORTD = (1 << 0) | (0 << 1) | (0 << 2) | (0 << 3);
	if (PIND & 0x10)
	{
		while (1)
		{
			if ((PIND & 0x10) == 0)
				break;
		}
		handle_number(7);
	}
	else if (PIND & 0x20)
	{
		while (1)
		{
			if ((PIND & 0x20) == 0)
				break;
		}
		handle_number(8);
	}
	else if (PIND & 0x60)
	{
		while (1)
		{
			if ((PIND & 0x60) == 0)
				break;
		}
		handle_number(9);
	}
	else if (PIND & 0x80)
	{
		while (1)
		{
			if ((PIND & 0x80) == 0)
				break;
		}
		handle_sign('/');
	}

	/********************************Check Second Row****************************/
	PORTD = (1 << 1) | (0 << 0) | (0 << 2) | (0 << 3);
	if (PIND & 0x10)
	{
		while (1)
		{
			if ((PIND & 0x10) == 0)
				break;
		}
		handle_number(4);
	}
	else if (PIND & 0x20)
	{
		while (1)
		{
			if ((PIND & 0x20) == 0)
				break;
		}
		handle_number(5);
	}
	else if (PIND & 0x40)
	{
		while (1)
		{
			if ((PIND & 0x40) == 0)
				break;
		}
		handle_number(6);
	}
	else if (PIND & 0x80)
	{
		while (1)
		{
			if ((PIND & 0x80) == 0)
				break;
		}

		handle_sign('*');
	}

	/********************************Check Third Row****************************/
	PORTD = (1 << 2) | (0 << 0) | (0 << 1) | (0 << 3);
	if (PIND & 0x10)
	{
		while (1)
		{
			if ((PIND & 0x10) == 0)
				break;
		}
		handle_number(1);
	}
	else if (PIND & 0x20)
	{
		while (1)
		{
			if ((PIND & 0x20) == 0)
				break;
		}
		handle_number(2);
	}
	else if (PIND & 0x40)
	{
		while (1)
		{
			if ((PIND & 0x40) == 0)
				break;
		}
		handle_number(3);
	}
	else if (PIND & 0x80)
	{

		while (1)
		{
			if ((PIND & 0x80) == 0)
				break;
		}
		handle_sign('-');
	}

	/********************************Check Forth Row****************************/
	PORTD = (1 << 3) | (0 << 0) | (0 << 1) | (0 << 2);
	if (PIND & 0x10)
	{
		Lcd4_Clear();
		num = 0;
	}
	else if (PIND & 0x20)
	{
		while (1)
		{
			if ((PIND & 0x20) == 0)
				break;
		}
		handle_number(0);
	}
	else if (PIND & 0x40)
	{
		while (1)
		{
			if ((PIND & 0x40) == 0)
				break;
		}
		handle_sign('=');
		sign = '0';
	}
	else if (PIND & 0x80)
	{
		while (1)
		{
			if ((PIND & 0x80) == 0)
				break;
		}

		handle_sign('+');
	}
}

//Write data to LCD
void LCD_Write()
{
	Lcd4_Set_Cursor(1, 1);
	char snum[10];
	ltoa(sum, snum, 10);
	Lcd4_Write_String(snum);
}

