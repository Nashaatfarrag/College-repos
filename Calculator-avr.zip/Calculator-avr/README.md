# Calculator-avr

## Basic 8 bit Calculator

### components

- keypad 4*4
- LCD 16*2
- ATMEL atmega16 avr microcontroller

### Requirements

- ATMEL Studio 7 or higher

- Proteus 8 Professional or higher

### Usage

- compile the C code with ATMEL Studio

- simulate the project with Proteus studio using the .hex file previously compiled
