# Discrete-Fast-Fourier-transform
two algorithm to calculate Fourier transform
*Discrete Fourier transform
*Radix-2 Fast Fourier transform

[Facebook Account](https://www.facebook.com/nashaatfarrag)
